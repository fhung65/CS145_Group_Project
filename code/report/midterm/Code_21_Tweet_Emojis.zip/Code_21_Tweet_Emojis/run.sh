#!/bin/sh
python3 code/scraper.py
