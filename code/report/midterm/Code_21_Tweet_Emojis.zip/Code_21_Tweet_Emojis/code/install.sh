#!/bin/sh
pip3 install tweepy
